import 'package:flutter/material.dart';
import '../constants/constants.dart';
import '../data/dummy_data.dart';
import '../widgets/item_card.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Home'),
        backgroundColor: kAppBarColor,
      ),
      backgroundColor: kBackgroundColor,
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: dummyItems.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 3 / 4,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
        ),
        itemBuilder: (context, index) {
          final item = dummyItems[index];
          return ItemCard(item: item);
        },
      ),
    );
  }
}
